
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
from scipy.stats import ttest_ind

# Load the dataset
df = pd.read_csv('pharma_sales_data.csv')

# Display the first few rows
print(df.head())

# Parse dates and set the date column as the index
df['Date'] = pd.to_datetime(df['Date'])
df.set_index('Date', inplace=True)

# Check for missing values
print(df.isnull().sum())

# If there are missing values, we can fill them (e.g., forward fill)
df.fillna(method='ffill', inplace=True)

# Plot the sales data
plt.figure(figsize=(12, 6))
plt.plot(df['Sales'], label='Sales')
plt.title('Sales Over Time')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.legend()
plt.show()

# Decompose the time series
decomposition = seasonal_decompose(df['Sales'], model='additive', period=12)

# Plot the decomposed components
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 12))
decomposition.trend.plot(ax=ax1)
ax1.set_ylabel('Trend')
decomposition.seasonal.plot(ax=ax2)
ax2.set_ylabel('Seasonality')
decomposition.resid.plot(ax=ax3)
ax3.set_ylabel('Residuals')
plt.show()

# Split the data into training and testing sets
train_size = int(len(df) * 0.8)
train, test = df.iloc[:train_size], df.iloc[train_size:]

# Fit the ARIMA model
model = ARIMA(train['Sales'], order=(5, 1, 0))
model_fit = model.fit()

# Forecast
forecast = model_fit.forecast(steps=len(test))

# Calculate MSE
mse = mean_squared_error(test['Sales'], forecast)
print(f'Mean Squared Error: {mse}')

# Plot the forecast against actual sales
plt.figure(figsize=(12, 6))
plt.plot(train['Sales'], label='Training Data')
plt.plot(test['Sales'], label='Actual Sales')
plt.plot(test.index, forecast, label='Forecasted Sales', color='red')
plt.title('Sales Forecasting')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.legend()
plt.show()

# Define two periods for comparison
period1 = df['2022-01':'2022-06']['Sales']
period2 = df['2022-07':'2022-12']['Sales']

# Perform t-test
t_stat, p_value = ttest_ind(period1, period2)
print(f'T-statistic: {t_stat}, P-value: {p_value}')

# Interpret the result
alpha = 0.05
if p_value < alpha:
    print('Reject the null hypothesis: Significant difference exists.')
else:
    print('Fail to reject the null hypothesis: No significant difference.')
