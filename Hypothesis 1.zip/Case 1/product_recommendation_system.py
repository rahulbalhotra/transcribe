
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind
from surprise import Dataset, Reader, SVD
from surprise.model_selection import train_test_split
from surprise import accuracy

# Step 1: Load the dataset
df = pd.read_csv('pharma_sales_data.csv')

# Step 2: Data Preparation
df['Date'] = pd.to_datetime(df['Date'])  # Convert 'Date' to datetime format
df.dropna(inplace=True)  # Drop missing values
df.drop_duplicates(inplace=True)  # Remove duplicate records

# Step 3: Exploratory Data Analysis
# Top 10 most sold products
top_products = df['ProductID'].value_counts().head(10)
top_products.plot(kind='bar')
plt.title('Top 10 Most Sold Products')
plt.xlabel('ProductID')
plt.ylabel('Number of Sales')
plt.show()

# Sales over time
df.set_index('Date')['Revenue'].resample('M').sum().plot()
plt.title('Monthly Revenue Over Time')
plt.xlabel('Date')
plt.ylabel('Revenue')
plt.show()

# Step 4: Hypothesis Testing
# Define high and low revenue customers
high_revenue_customers = df[df['Revenue'] > df['Revenue'].quantile(0.75)]['CustomerID'].unique()
low_revenue_customers = df[df['Revenue'] < df['Revenue'].quantile(0.25)]['CustomerID'].unique()

# Average price of products purchased by high and low revenue customers
high_revenue_prices = df[df['CustomerID'].isin(high_revenue_customers)]['Price']
low_revenue_prices = df[df['CustomerID'].isin(low_revenue_customers)]['Price']

# Perform t-test
t_stat, p_value = ttest_ind(high_revenue_prices, low_revenue_prices)
print(f'T-statistic: {t_stat}, P-value: {p_value}')

# Step 5: Build the Recommendation System
reader = Reader(rating_scale=(1, 5))
data = Dataset.load_from_df(df[['CustomerID', 'ProductID', 'Rating']], reader)

# Split data into training and testing sets
trainset, testset = train_test_split(data, test_size=0.2)

# Train SVD model
model = SVD()
model.fit(trainset)

# Evaluate the model
predictions = model.test(testset)
rmse = accuracy.rmse(predictions)
print(f'RMSE: {rmse}')

# Step 6: Making Recommendations
def get_recommendations(customer_id, model, df, n=5):
    all_products = df['ProductID'].unique()
    purchased_products = df[df['CustomerID'] == customer_id]['ProductID'].unique()
    products_to_predict = [pid for pid in all_products if pid not in purchased_products]
    predictions = [model.predict(customer_id, pid) for pid in products_to_predict]
    predictions.sort(key=lambda x: x.est, reverse=True)
    top_recommendations = predictions[:n]
    return [(pred.iid, pred.est) for pred in top_recommendations]

# Example usage
customer_id = 'C123'
recommendations = get_recommendations(customer_id, model, df)
print(f'Recommendations for Customer {customer_id}: {recommendations}')
